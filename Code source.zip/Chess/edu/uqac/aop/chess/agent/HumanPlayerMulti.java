package uqac.aop.chess.agent;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import uqac.aop.chess.Board;
import uqac.aop.network.Room;

public class HumanPlayerMulti extends HumanPlayer {

	private Socket s;
	private BufferedReader br;
	private PrintWriter pw;
	private Room room;

	public HumanPlayerMulti(int arg, Board board, Room room, Socket s) {
		super(arg, board);
		this.s = s;
		this.room = room;
		initIO();
	}

	public Socket getSocket() {
		return this.s;
	}
	
	public Room getRoom() {
		return this.room;
	}
	public void initIO() {

		try {
			OutputStream os;
			os = s.getOutputStream();
			pw = new PrintWriter(os, true);

			InputStream is = s.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			br = new BufferedReader(isr);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public Move makeMove() {
		Move mv;
		char initialX = '\0';
		char initialY = '\0';
		char finalX = '\0';
		char finalY = '\0';
		String gameIndicator = getColor()==Player.BLACK ? "<a2a4>" : "<a7a5>"; 
		try {
			do {
				
				pw.println("Votre coup? "+ gameIndicator);
				String ans = br.readLine();
				initialX = ans.charAt(0);
				initialY = ans.charAt(1);
				finalX = ans.charAt(2);
				finalY = ans.charAt(3);

				mv = new Move(initialX - 'a', initialY - '1', finalX - 'a', finalY - '1');
			} while (!makeMove(mv));
			return mv;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

}
