package uqac.aop.aspects;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

import uqac.aop.chess.Board;
import uqac.aop.chess.agent.HumanPlayerMulti;
import uqac.aop.chess.agent.Move;
import uqac.aop.chess.agent.Player;
import uqac.aop.chess.piece.Knight;
import uqac.aop.chess.piece.Pawn;
import uqac.aop.chess.piece.Piece;

@Aspect
public class MovesControl {
//	// D�placements des pi�ces du joueur
//	@Pointcut("execution(* uqac.aop.chess.agent.HumanPlayer.makeMove(..)) && args(mv)")
//	public void deplacements (Move mv) {
//	}
//	
//	// Contr�le si la pi�ce appartient au joueur
//	@Around ("deplacements(mv)")
//	public boolean isPlayerPiece (Move mv, JoinPoint jp, ProceedingJoinPoint pjp) {
//		
//		Player player = (Player)jp.getTarget();
//		Piece playgroundPiece = player.getPlayGround().getGrid()[mv.xI][mv.yI].getPiece();
//		boolean isPlayerPiece = !(playgroundPiece.getPlayer() == player.getColor());
//		boolean returnValue = false;
//		
//		
//		if (isPlayerPiece) {
//			try {
//				returnValue = (boolean) pjp.proceed();
//			} catch (Throwable e) {
//				e.printStackTrace();
//			}
//		}
//		else {
//			System.out.println("Vous ne pouvez pas d�placer cette pi�ce car elle appartient � l'adversaire");
//			if (player instanceof HumanPlayerMulti) {
//				Socket s = ((HumanPlayerMulti) player).getSocket();
//				
//				try {
//					OutputStream os;
//					os = s.getOutputStream();
//					PrintWriter pw = new PrintWriter(os, true);
//					pw.println("Vous ne pouvez pas d�placer cette pi�ce car elle appartient � l'adversaire");
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//	
//			}
//		}
//		return returnValue;
//	}
//	
//	// Contr�le si le mouvement n'est pas � l'ext�rieur du tableau
//	@Around ("deplacements(mv)")
//	public boolean isMoveOutside (Move mv, JoinPoint jp, ProceedingJoinPoint pjp) {
//		
//		Player player = (Player)jp.getTarget();
//		int boardSize = player.getPlayGround().SIZE;
//		
//		boolean returnValue = false;
//		
//		if ((mv.xF>=0 && mv.xF<boardSize) && (mv.yF>=0 && mv.yF<boardSize) ) {
//			try {
//				returnValue = (boolean) pjp.proceed();
//			} catch (Throwable e) {
//				e.printStackTrace();
//			}
//		}
//		else {
//			System.out.println("Vous ne pouvez pas d�placer cette pi�ce � l'ext�rieur du tableau");
//		}
//		return returnValue;
//	}
//	
//	//V�rifie que la pi�ce n'en saute pas une autre 
//	
//	@Around ("deplacements(mv)")
//	public boolean isMoveCollision (Move mv, JoinPoint jp, ProceedingJoinPoint pjp) {
//		
//		
//		Player player = (Player)jp.getTarget();
//		Board playground = player.getPlayGround();
//		Piece playgroundPiece = player.getPlayGround().getGrid()[mv.xI][mv.yI].getPiece();
//		boolean returnValue = false;
//		
//		
//		//V�rifie d'abord si la pi�ce n'est pas un cavalier :  pas besoin de ce contr�le pour le cavalier
//		if(!playgroundPiece.getClass().equals(new Knight(0).getClass())) {
//	
//			for (int i=Math.min(mv.xI,mv.xF); i<=Math.max(mv.xI, mv.xF); i++ ) {
//				for (int j=Math.min(mv.yI,mv.yF); j<=Math.max(mv.yI, mv.yF); j++ ) {
//					
//					if (i==Math.min(mv.xI,mv.xF) && j==Math.min(mv.yI,mv.yF) ) {
//						continue;
//					}
//					else if (i==Math.max(mv.xI,mv.xF) && j==Math.max(mv.yI,mv.yF) ) {
//						continue;
//					}
//					else {
//						if (playgroundPiece.isMoveLegal(new Move(mv.xI,i,mv.xF,j))) {
//							if(playground.getGrid()[i][j].isOccupied()) {
//								System.out.println("Vous ne pouvez effectuer ce d�placement : Vous sautez une ou plusieurs pi�ce");
//								return false;
//							}
//						}
//					}
//						
//				}	
//			}
//		}
//			try {
//				returnValue = (boolean) pjp.proceed();
//			} catch (Throwable e) {
//				e.printStackTrace();
//			}
//			
//			return returnValue;
//
//	}
}
