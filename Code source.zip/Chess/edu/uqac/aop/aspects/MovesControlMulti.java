package uqac.aop.aspects;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

import uqac.aop.chess.Board;
import uqac.aop.chess.agent.HumanPlayerMulti;
import uqac.aop.chess.agent.Move;
import uqac.aop.chess.agent.Player;
import uqac.aop.chess.piece.Knight;
import uqac.aop.chess.piece.Pawn;
import uqac.aop.chess.piece.Piece;

@Aspect
public class MovesControlMulti {
	// D�placements des pi�ces du joueur
	@Pointcut("execution(* uqac.aop.chess.agent.HumanPlayer.makeMove(..)) && args(mv)")
	public void deplacements(Move mv) {
	}

	// Contr�le si le joueur d�place bien une pi�ce et non une case vide
	@Around("deplacements(mv)")
	public boolean isPiece(Move mv, JoinPoint jp, ProceedingJoinPoint pjp) {
		Player player = (Player) jp.getTarget();

		Socket s = ((HumanPlayerMulti) player).getSocket();
		String ip = s.getRemoteSocketAddress().toString();

		boolean isOccupied = player.getPlayGround().getGrid()[mv.xI][mv.yI].isOccupied();
		boolean returnValue = false;

		if (isOccupied) {
			try {
				returnValue = (boolean) pjp.proceed();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} else {
			try {
				OutputStream os;
				os = s.getOutputStream();
				PrintWriter pw = new PrintWriter(os, true);
				pw.println("Vous ne pouvez pas d�placer une case vide");
				System.out.println("Le client : " + ip + "ne peut pas d�placer une case vide");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return returnValue;
	}

	// Contr�le si la pi�ce appartient au joueur
	@Around("deplacements(mv)")
	public boolean isPlayerPiece(Move mv, JoinPoint jp, ProceedingJoinPoint pjp) {

		Player player = (Player) jp.getTarget();
		Socket s = ((HumanPlayerMulti) player).getSocket();
		String ip = s.getRemoteSocketAddress().toString();
		Piece playgroundPiece = player.getPlayGround().getGrid()[mv.xI][mv.yI].getPiece();
		boolean isPlayerPiece = !(playgroundPiece.getPlayer() == player.getColor());
		boolean returnValue = false;

		if (isPlayerPiece) {
			try {
				returnValue = (boolean) pjp.proceed();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} else {

			try {
				OutputStream os;
				os = s.getOutputStream();
				PrintWriter pw = new PrintWriter(os, true);
				pw.println("Vous ne pouvez pas d�placer cette pi�ce car elle appartient � l'adversaire");
				System.out.println(
						"Le client : " + ip + "ne peut d�placer cette pi�ce car elle appartient � l'adversaire");
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		return returnValue;
	}

	// Contr�le si le mouvement n'est pas � l'ext�rieur du tableau
	@Around("deplacements(mv)")
	public boolean isMoveOutside(Move mv, JoinPoint jp, ProceedingJoinPoint pjp) {
		Player player = (Player) jp.getTarget();
		Socket s = ((HumanPlayerMulti) player).getSocket();
		String ip = s.getRemoteSocketAddress().toString();

		int boardSize = player.getPlayGround().SIZE;

		boolean returnValue = false;

		if ((mv.xF >= 0 && mv.xF < boardSize) && (mv.yF >= 0 && mv.yF < boardSize)) {
			try {
				returnValue = (boolean) pjp.proceed();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} else {
			try {
				OutputStream os;
				os = s.getOutputStream();
				PrintWriter pw = new PrintWriter(os, true);
				pw.println("Vous ne pouvez pas d�placer cette pi�ce � l'ext�rieur du tableau");
				System.out.println("Le client : " + ip + "ne peut pas d�placer cette pi�ce � l'ext�rieur du tableau");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return returnValue;
	}

	// V�rifie que la pi�ce n'en saute pas une autre

	@Around("deplacements(mv)")
	public boolean isMoveCollision(Move mv, JoinPoint jp, ProceedingJoinPoint pjp) {

		Player player = (Player) jp.getTarget();

		Socket s = ((HumanPlayerMulti) player).getSocket();
		String ip = s.getRemoteSocketAddress().toString();

		Board playground = player.getPlayGround();
		Piece playgroundPiece = player.getPlayGround().getGrid()[mv.xI][mv.yI].getPiece();
		boolean returnValue = false;

		// V�rifie d'abord si la pi�ce n'est pas un cavalier : pas besoin de ce contr�le
		// pour le cavalier
		if (!playgroundPiece.getClass().equals(new Knight(0).getClass())) {

			for (int i = Math.min(mv.xI, mv.xF); i <= Math.max(mv.xI, mv.xF); i++) {
				for (int j = Math.min(mv.yI, mv.yF); j <= Math.max(mv.yI, mv.yF); j++) {

					if (i == Math.min(mv.xI, mv.xF) && j == Math.min(mv.yI, mv.yF)) {
						continue;
					} else if (i == Math.max(mv.xI, mv.xF) && j == Math.max(mv.yI, mv.yF)) {
						continue;
					} else {
						if (playgroundPiece.isMoveLegal(new Move(mv.xI, i, mv.xF, j))) {
							if (playground.getGrid()[i][j].isOccupied()) {
								OutputStream os;
								try {
									os = s.getOutputStream();
									PrintWriter pw = new PrintWriter(os, true);
									pw.println(
											"Vous ne pouvez effectuer ce d�placement : Vous sautez une ou plusieurs pi�ce");
									System.out.println("Le client : " + ip
											+ " ne peut effectuer ce d�placement : Il saute une ou plusieurs pi�ce");
									System.out.println(
											"Vous ne pouvez effectuer ce d�placement : Vous sautez une ou plusieurs pi�ce");

								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								return false;
							}
						}
					}

				}
			}
		}
		try {
			returnValue = (boolean) pjp.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}

		return returnValue;

	}

	// V�rifie que la pi�ce ne mange pas une autre pi�ce du joueur
	@Around("deplacements(mv)")
	public boolean doesNotEatPlayerPiece(Move mv, JoinPoint jp, ProceedingJoinPoint pjp) {

		Player player = (Player) jp.getTarget();
		Socket s = ((HumanPlayerMulti) player).getSocket();
		String ip = s.getRemoteSocketAddress().toString();

		Piece playgroundPiece = player.getPlayGround().getGrid()[mv.xI][mv.yI].getPiece();

		boolean isOccupied = player.getPlayGround().getGrid()[mv.xF][mv.yF].isOccupied();
		boolean returnValue = false;
		boolean isPlayerPiece = false;

		if (isOccupied) {
			Piece occupiedPiece = player.getPlayGround().getGrid()[mv.xF][mv.yF].getPiece();
			isPlayerPiece = (occupiedPiece.getPlayer() == playgroundPiece.getPlayer());
		}
		if (!isPlayerPiece) {
			try {
				returnValue = (boolean) pjp.proceed();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} else {
			try {
				OutputStream os;
				os = s.getOutputStream();
				PrintWriter pw = new PrintWriter(os, true);
				pw.println("Vous ne pouvez bouffer cette pi�ce car elle vous appartient");
				System.out.println("Le client : " + ip + "ne peut bouffer cette pi�ce car elle lui appartient");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return returnValue;
	}

	// Contr�le si le mouvement est autoris� par la pi�ce
	@Around("deplacements(mv)")
	public boolean isMoveLegalByPiece(Move mv, JoinPoint jp, ProceedingJoinPoint pjp) {
		Player player = (Player) jp.getTarget();

		Socket s = ((HumanPlayerMulti) player).getSocket();
		String ip = s.getRemoteSocketAddress().toString();

		Piece playgroundPiece = player.getPlayGround().getGrid()[mv.xI][mv.yI].getPiece();
		boolean isMoveLegal = playgroundPiece.isMoveLegal(mv);
		boolean returnValue = false;

		if (isMoveLegal) {
			try {
				returnValue = (boolean) pjp.proceed();
			} catch (Throwable e) {
				e.printStackTrace();
			}
		} else {
			try {
				OutputStream os;
				os = s.getOutputStream();
				PrintWriter pw = new PrintWriter(os, true);
				pw.println("Ce mouvement n'est pas autoris� par la pi�ce que vous souhaitez d�placer");
				System.out.println(
						"Le client : " + ip + "ne peut effectuer ce mouvement avec la pi�ce qu'il souhaite d�placer");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return returnValue;
	}
	
	

}
