package uqac.aop.aspects;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

import uqac.aop.chess.agent.Move;
import uqac.aop.chess.agent.Player;

@Aspect 
public class Journalisation {
	
	//Initialisation de la partie
	@Before("execution(* *.main(..))")
	public void initialisation () {
		writeInFile("---------------------");
		writeInFile("Nouvelle partie");
		writeInFile("---------------------");
	}
	
	// D�placements des pi�ces
	@Pointcut("execution(* *.makeMove(..)) && args(mv)")
	public void deplacements (Move mv) {
	}
	
	@AfterReturning (
			pointcut="deplacements(mv)",
			returning="is_moved"
			)
	public void saveMove (Move mv, Boolean is_moved, JoinPoint jp) {
		Player player = (Player)jp.getTarget();
		if (is_moved) {
			String coup = playerColourToString(player.getColor()) + " : "+playerMoveToString(mv);
			writeInFile(coup);
		}	
	}
	
	//Fin de la partie
	@After("execution(* *.main(..))")
	public void cloture () {
		writeInFile("---------------------");
		writeInFile("Fin de la partie");
		writeInFile("---------------------");
	}
	
	
	public String playerColourToString (int color) {
		if (color == 0) return "BLACK";
			return "WHITE";	
	}
	
	public String playerMoveToString (Move mv) {
		
		return  (char)('a' + mv.xI) + "" + (mv.yI+1) + (char)('a' + mv.xF) + "" + (mv.yF+1);
	}
	
	
	// Ecriture dans le fichier journal
	public void writeInFile (String content) {
		 try {
			 File file = new File("journal_des_coups.txt");
	
			 // cr�er le fichier s'il n'existe pas
			 if (!file.exists()) {
				file.createNewFile();
			 }
			 
			 FileWriter fw = new FileWriter(file.getAbsoluteFile(), true);
			 BufferedWriter bw = new BufferedWriter(fw);
			 bw.write(content);
			 bw.newLine();
			 bw.close();
		 } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		 }
	}
}
