package uqac.aop.aspects;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.DeclarePrecedence;
import org.aspectj.lang.annotation.Pointcut;

import uqac.aop.chess.Board;
import uqac.aop.chess.agent.HumanPlayerMulti;
import uqac.aop.chess.agent.Move;
import uqac.aop.chess.agent.Player;
import uqac.aop.chess.piece.King;
import uqac.aop.chess.piece.Knight;
import uqac.aop.chess.piece.Pawn;
import uqac.aop.chess.piece.Piece;
import uqac.aop.network.Room;

@Aspect
@DeclarePrecedence("uqac.aop.aspects.MovesControlMulti.*")
public class GameMultiControl {
	// D�placements des pi�ces du joueur
	@Pointcut("execution(* uqac.aop.chess.agent.HumanPlayer.makeMove(..)) && args(mv)")
	public void deplacements(Move mv) {
	}

	// D�tecte si le King est bouff� et met fin � la partie si c'est le cas
	@Around("deplacements(mv)")
	public boolean gameOver(Move mv, JoinPoint jp, ProceedingJoinPoint pjp) {

		HumanPlayerMulti player = (HumanPlayerMulti) jp.getTarget();
		Socket s =  player.getSocket();
		String ip = s.getRemoteSocketAddress().toString();

		Piece playgroundPiece = player.getPlayGround().getGrid()[mv.xI][mv.yI].getPiece();
		Piece pieceToEat = player.getPlayGround().getGrid()[mv.xF][mv.yF].getPiece();
		boolean isOccupied = player.getPlayGround().getGrid()[mv.xF][mv.yF].isOccupied();
		
		boolean isPlayerPiece = false;
		boolean isKingPiece = false;
		boolean returnValue = false;
		
		try {
			returnValue = (boolean) pjp.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}

		if (returnValue) {
			if (isOccupied) {
				
				isPlayerPiece = (pieceToEat.getPlayer() == playgroundPiece.getPlayer());
				isKingPiece = pieceToEat.getClass().equals(new King(0).getClass());
				
				if (!isPlayerPiece && isKingPiece) {
					// D�finit le vainqueur de la partie et indique la fin de partie
					Room playerGameRoom =player.getRoom();
					playerGameRoom.setWinner(player.getColor());
					playerGameRoom.setGameFinished(true);
					System.out.println("Le joueur IP = "+ip+" remporte la partie");
				}
			}
		}
		
	return returnValue;	
	}

	

}
