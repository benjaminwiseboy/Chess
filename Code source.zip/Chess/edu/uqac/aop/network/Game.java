package uqac.aop.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.stream.Collectors;

import uqac.aop.chess.agent.HumanPlayerMulti;
import uqac.aop.chess.agent.Player;

public class Game  extends Thread{

	private BufferedReader br;
	private PrintWriter pw;

	private Socket socket;
	private Serveur parentServer;
	
	private Room room;
	private int playerColor;
	private String playerColorLabel;
	private Player hp;

	public Game(Socket socket, Room room, Serveur serveur) {
		this.socket = socket;
		this.room = room;
		this.parentServer = serveur;
		initIO();

	}

	public void initIO() {

		try {
			InputStream is;
			is = socket.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			br = new BufferedReader(isr);

			OutputStream os = socket.getOutputStream();
			pw = new PrintWriter(os, true);

		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	public void initGame() {

		playerColor = room.getNbPlayers() % 2 == 0 ? Player.WHITE : Player.BLACK;
		playerColorLabel = generatePlayerColorLabel(playerColor); 
		hp = new HumanPlayerMulti(playerColor, room.getBoard(), room, socket);
		String IP = socket.getRemoteSocketAddress().toString();

		System.out.println("Connexion du client numero" + room.getNbPlayers() + ", IP=" + IP);
		

	}
	
	public String generatePlayerColorLabel (int color) {
		return color == Player.WHITE ? "WHITE" : "BLACK";
	}
	
	public void displayBoard () {
		
		// Commandes pour vider l'affichage de la fen�tre console
		pw.print("\033[H\033[2J");
	    pw.flush();
	    
	    pw.println("Num�ro de salon : "+ room.getNumber());
		pw.println("Vous �tes le joueur :  " + playerColorLabel);
		pw.println(room.getBoard().toString());
	}

	@Override
	public synchronized void run() {
		initGame();

		while (!room.isGameFinished()) {

			if (room.getNbPlayers()==2) {
				if (room.getTurn() == playerColor) {
					displayBoard();
					hp.makeMove();
					room.setTurn(playerColor == Player.WHITE ? Player.BLACK : Player.WHITE);
					// notify();
				} else {

					displayBoard();
					pw.println("En attente du coup de l'adversaire...");
					while (room.getTurn() != playerColor) {
						try {
							Thread.currentThread();
							Thread.sleep(100);
						} catch (Exception e) {
						}
					}
				}
			}
			else {
				displayBoard();
				pw.println("En attente d'un adversaire...");
				while (room.getNbPlayers()!=2) {
					try {
						Thread.currentThread();
						Thread.sleep(100);
					} catch (Exception e) {
					}
				}
			}
		}
		
		try {
			// Affichage du vainqueur
			if (playerColor==room.getWinner()) pw.println("F�licitations vous avez remport� la partie\n");
			else pw.println("\nDommage vous avez perdu la partie. Vous ferez mieux la prochaine fois\n");
			pw.println("Appuyez sur une touche pour continuer....");
			Thread.sleep(100);
			
			// Retire le salon en cours de la liste des salons du serveur
			parentServer.rooms = parentServer.rooms.stream().filter(r-> r.getNumber()!=room.getNumber()).collect(Collectors.toList());
			
			// Redirection vers le menu principal
			new MainScreen(this.socket, this.parentServer).start();
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}


