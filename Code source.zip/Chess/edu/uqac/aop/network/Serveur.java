package uqac.aop.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;



public class Serveur extends Thread {
	List<Room> rooms = new ArrayList<Room>();
	int nbRooms = 1;

	public static void main(String[] args) {
		new Serveur().start();
	}

	@Override
	public void run() {
		try {
			ServerSocket ss = new ServerSocket(1234);
			System.out.println("D�marrage du serveur");

			while (true) {
				Socket s = ss.accept();
				new MainScreen(s, this).start();
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	
}

	