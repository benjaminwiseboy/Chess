package uqac.aop.network;

import uqac.aop.chess.Board;
import uqac.aop.chess.agent.Player;

public class Room {

	private int number;
	private Board board;
	private int turn;
	private int nbPlayers;
	private boolean isGameFinished;
	private int winner;

	public void init(int num) {
		board = new Board();
		board.setupChessBoard();
		System.out.println("Cr�ation de la table d'�checs");

		turn = Player.BLACK;
		nbPlayers = 0;
		number = num;
		
		winner = 0;
		isGameFinished = false;

	}

	public int getTurn() {
		return this.turn;
	}

	public void setTurn(int turn) {
		this.turn = turn;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public Board getBoard() {
		return board;
	}

	public void setBoard(Board board) {
		this.board = board;
	}

	public int getNbPlayers() {
		return nbPlayers;
	}

	public void setNbPlayers(int nbPlayers) {
		this.nbPlayers = nbPlayers;
	}

	public boolean isGameFinished() {
		return isGameFinished;
	}

	public void setGameFinished(boolean isGameFinished) {
		this.isGameFinished = isGameFinished;
	}

	public int getWinner() {
		return winner;
	}

	public void setWinner(int winner) {
		this.winner = winner;
	}
	
	
}
