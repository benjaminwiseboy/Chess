package uqac.aop.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client extends Thread{

	private PrintWriter pw;
	private BufferedReader br;
	
	public Client () {
		try {
			Socket s = new Socket("localhost", 1234);
			
			InputStream is = s.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			OutputStream os = s.getOutputStream();
			
			br = new BufferedReader(isr);
			pw = new PrintWriter(os, true);
			
			Scanner sc = new Scanner(System.in);
			
			this.start();
			while (true) {
				
				String req = sc.nextLine();
				pw.println(req);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		new Client().start();
	}
	
	public void run() {
		while (true) {
			try {
				String rep = br.readLine();
				System.out.println(rep);
			} catch (IOException e) {
				e.printStackTrace(); 
			}
			
		}
	}


}
