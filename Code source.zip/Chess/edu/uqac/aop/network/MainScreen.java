package uqac.aop.network;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;
import java.util.stream.Collectors;

public class MainScreen extends Thread {

	private Socket s;
	private Serveur parentServer;

	public MainScreen(Socket s, Serveur parentServer) {
		super();
		this.s = s;
		this.parentServer = parentServer;
	}

	public Socket getSocket() {
		return s;
	}

	public Serveur getParentServer() {
		return parentServer;
	}

	public void run() {
		
			try {
				InputStream is = s.getInputStream();
				InputStreamReader isr = new InputStreamReader(is);
				BufferedReader br = new BufferedReader(isr);

				OutputStream os = s.getOutputStream();
				PrintWriter pw = new PrintWriter(os, true);
				
				// Commandes pour vider l'affichage de la fen�tre console

				pw.println("Bienvenue dans Chess Game\n");
				pw.println("Souhaitez vous :\n\r 1- Cr�er un nouveau salon \n\r 2- Rejoindre un salon");
				int ans = Integer.parseInt(br.readLine());

				switch (ans) {
				case 1:
					// Cr�ation et initialisation du salon ; Ajout du nouveau salon dans la liste des salons
					Room room = new Room();
					parentServer.rooms.add(room);
					room.init(parentServer.nbRooms);
					parentServer.nbRooms++;
					
					new GameController(s, room, parentServer).start();
					break;
				case 2:
					pw.println("Entrez le numero de salon � rejoindre");
					int num = Integer.parseInt(br.readLine());
					List<Room> roomToJoin = parentServer.rooms.stream().filter(r -> r.getNumber() == num)
							.collect(Collectors.toList());

					if (!roomToJoin.isEmpty())
						new GameController(s, roomToJoin.get(0), parentServer).start();
					else
						pw.println("Le num�ro renseign� ne correspond � aucun salon");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		

	}

}
